<?php /* V2.10 Template Lite 4 January 2007  (c) 2005-2007 Mark Dickenson. All rights reserved. Released LGPL. 2013-07-23 18:17 CST */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<meta http-equiv="X-UA-Compatible" content="IE=7">
<link rel="shortcut icon" href="<?php echo $this->_vars['QISHI']['site_dir']; ?>
favicon.ico" />
<title>��վ��̨�������� - Powered by 74CMS</title>
<link href="css/common.css" rel="stylesheet" type="text/css" />
</head>
</head>
<frameset rows="70,*" frameborder="no" border="0" framespacing="0" >
        <frame src="admin_index.php?act=top" name="topFrame" id="topFrame" scrolling="no" frameborder="NO" border="0" framespacing="0">
        <frameset cols="200,*"  name="bodyFrame" id="bodyFrame" frameborder="no" border="0" framespacing="0">
            <frame src="admin_left.php" name="leftFrame" frameborder="no" scrolling="no" noresize id="leftFrame">
            <frame src="admin_index.php?act=main" name="mainFrame" frameborder="no" scrolling="auto" noresize id="mainFrame">
        </frameset>
</frameset>
    <noframes>
        <body>����������֧�ֿ��</body>
    </noframes>
</html>