<?php /* V2.10 Template Lite 4 January 2007  (c) 2005-2007 Mark Dickenson. All rights reserved. Released LGPL. 2013-07-23 18:18 CST */ ?>
<div class="topnav">
<a href="?act=jobfair" <?php if ($this->_vars['act'] == 'jobfair'): ?>class="select"<?php endif; ?>><u>��Ƹ��</u></a>
<a href="?act=jobfair_add" <?php if ($this->_vars['act'] == 'jobfair_add'): ?>class="select"<?php endif; ?>><u>������Ƹ��</u></a> 
<div class="clear"></div>
</div>