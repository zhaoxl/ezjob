<?php /* V2.10 Template Lite 4 January 2007  (c) 2005-2007 Mark Dickenson. All rights reserved. Released LGPL. 2013-07-23 18:18 CST */ ?>
<div class="topnav">
<a href="?act=qq_set" <?php if ($this->_vars['navlabel'] == 'qq_set'): ?>class="select"<?php endif; ?>><u>QQ�ʺŵ�¼</u></a>
<a href="?act=sina_set" <?php if ($this->_vars['navlabel'] == 'sina_set'): ?>class="select"<?php endif; ?>><u>����΢����¼</u></a>
<a href="?act=taobao_set" <?php if ($this->_vars['navlabel'] == 'taobao_set'): ?>class="select"<?php endif; ?>><u>�Ա��ʺŵ�¼</u></a>
<div class="clear"></div>
</div>