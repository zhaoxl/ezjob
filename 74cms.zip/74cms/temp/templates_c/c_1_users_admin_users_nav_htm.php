<?php /* V2.10 Template Lite 4 January 2007  (c) 2005-2007 Mark Dickenson. All rights reserved. Released LGPL. 2013-07-23 18:17 CST */ ?>
<div class="topnav">
<a href="?act=list" <?php if ($this->_vars['navlabel'] == 'list'): ?>class="select"<?php endif; ?>><u>����Ա�б�</u></a>
<a href="?act=add_users" <?php if ($this->_vars['navlabel'] == 'add'): ?>class="select"<?php endif; ?>><u>���ӹ���Ա</u></a>
<div class="clear"></div>
</div>