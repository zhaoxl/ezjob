<?php /* V2.10 Template Lite 4 January 2007  (c) 2005-2007 Mark Dickenson. All rights reserved. Released LGPL. 2013-07-19 22:30 CST */ ?>

<div class="topnav">
<a href="?act=list" <?php if ($this->_vars['navlabel'] == 'list'): ?>class="select"<?php endif; ?>><u>΢��Ƹ�б�</u></a>
<a href="?act=simple_add" <?php if ($this->_vars['navlabel'] == 'add'): ?>class="select"<?php endif; ?>><u>����΢��Ƹ</u></a> 
<div class="clear"></div>
</div>