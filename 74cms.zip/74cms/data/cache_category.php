<?php
$data = array (
  'QS_trade' => 
  array (
    1 => 
    array (
      'id' => '1',
      'parentid' => '0',
      'categoryname' => '���������/Ӳ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    2 => 
    array (
      'id' => '2',
      'parentid' => '0',
      'categoryname' => '�����ϵͳ/ά��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    3 => 
    array (
      'id' => '3',
      'parentid' => '0',
      'categoryname' => 'ͨ��(�豸/��Ӫ/����)',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    4 => 
    array (
      'id' => '4',
      'parentid' => '0',
      'categoryname' => '������/��������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    5 => 
    array (
      'id' => '5',
      'parentid' => '0',
      'categoryname' => '������Ϸ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    6 => 
    array (
      'id' => '6',
      'parentid' => '0',
      'categoryname' => '����/�뵼��/���ɵ�·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    7 => 
    array (
      'id' => '7',
      'parentid' => '0',
      'categoryname' => '�����Ǳ�/��ҵ�Զ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    8 => 
    array (
      'id' => '8',
      'parentid' => '0',
      'categoryname' => '���/���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    9 => 
    array (
      'id' => '9',
      'parentid' => '0',
      'categoryname' => '����(Ͷ��/֤ȯ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    10 => 
    array (
      'id' => '10',
      'parentid' => '0',
      'categoryname' => '����(����/����)',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    11 => 
    array (
      'id' => '11',
      'parentid' => '0',
      'categoryname' => 'ó��/������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    12 => 
    array (
      'id' => '12',
      'parentid' => '0',
      'categoryname' => '����/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    13 => 
    array (
      'id' => '13',
      'parentid' => '0',
      'categoryname' => '����Ʒ(ʳ/��/�̾�)',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    14 => 
    array (
      'id' => '14',
      'parentid' => '0',
      'categoryname' => '��װ/��֯/Ƥ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    15 => 
    array (
      'id' => '15',
      'parentid' => '0',
      'categoryname' => '�Ҿ�/�ҵ�/����Ʒ/���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    16 => 
    array (
      'id' => '16',
      'parentid' => '0',
      'categoryname' => '�칫��Ʒ���豸',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    17 => 
    array (
      'id' => '17',
      'parentid' => '0',
      'categoryname' => '��е/�豸/�ع�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    18 => 
    array (
      'id' => '18',
      'parentid' => '0',
      'categoryname' => '����/Ħ�г�/�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    19 => 
    array (
      'id' => '19',
      'parentid' => '0',
      'categoryname' => '��ҩ/���﹤��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    20 => 
    array (
      'id' => '20',
      'parentid' => '0',
      'categoryname' => 'ҽ��/����/����/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    21 => 
    array (
      'id' => '21',
      'parentid' => '0',
      'categoryname' => 'ҽ���豸/��е',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    22 => 
    array (
      'id' => '22',
      'parentid' => '0',
      'categoryname' => '���/�г��ƹ�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    23 => 
    array (
      'id' => '23',
      'parentid' => '0',
      'categoryname' => '��չ/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    24 => 
    array (
      'id' => '24',
      'parentid' => '0',
      'categoryname' => 'Ӱ��/ý��/����/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    25 => 
    array (
      'id' => '25',
      'parentid' => '0',
      'categoryname' => 'ӡˢ/��װ/��ֽ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    26 => 
    array (
      'id' => '26',
      'parentid' => '0',
      'categoryname' => '���ز�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    27 => 
    array (
      'id' => '27',
      'parentid' => '0',
      'categoryname' => '�����빤��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    28 => 
    array (
      'id' => '28',
      'parentid' => '0',
      'categoryname' => '�Ҿ�/�������/װ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    29 => 
    array (
      'id' => '29',
      'parentid' => '0',
      'categoryname' => '��ҵ����/��ҵ����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    30 => 
    array (
      'id' => '30',
      'parentid' => '0',
      'categoryname' => '�н����/��������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    31 => 
    array (
      'id' => '31',
      'parentid' => '0',
      'categoryname' => 'רҵ����/�ƻ�/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    32 => 
    array (
      'id' => '32',
      'parentid' => '0',
      'categoryname' => '���/��֤',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    33 => 
    array (
      'id' => '33',
      'parentid' => '0',
      'categoryname' => '����/��ѵ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    34 => 
    array (
      'id' => '34',
      'parentid' => '0',
      'categoryname' => 'ѧ��/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    35 => 
    array (
      'id' => '35',
      'parentid' => '0',
      'categoryname' => '����/����/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    36 => 
    array (
      'id' => '36',
      'parentid' => '0',
      'categoryname' => '�Ƶ�/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    37 => 
    array (
      'id' => '37',
      'parentid' => '0',
      'categoryname' => '��ͨ/����/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    38 => 
    array (
      'id' => '38',
      'parentid' => '0',
      'categoryname' => '����/����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    39 => 
    array (
      'id' => '39',
      'parentid' => '0',
      'categoryname' => '��Դ(ʯ��/����/���)',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    40 => 
    array (
      'id' => '40',
      'parentid' => '0',
      'categoryname' => '��Դ(�ɾ�/ұ��/ԭ����)',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    41 => 
    array (
      'id' => '41',
      'parentid' => '0',
      'categoryname' => '����/ˮ��/����Դ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    42 => 
    array (
      'id' => '42',
      'parentid' => '0',
      'categoryname' => '��������/��ҵ��λ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    43 => 
    array (
      'id' => '43',
      'parentid' => '0',
      'categoryname' => '��ӯ������/��ҵЭ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    44 => 
    array (
      'id' => '44',
      'parentid' => '0',
      'categoryname' => 'ũҵ/��ҵ/��ҵ/��ҵ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    45 => 
    array (
      'id' => '45',
      'parentid' => '0',
      'categoryname' => '������ҵ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_company_type' => 
  array (
    46 => 
    array (
      'id' => '46',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    47 => 
    array (
      'id' => '47',
      'parentid' => '0',
      'categoryname' => '��Ӫ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    48 => 
    array (
      'id' => '48',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    49 => 
    array (
      'id' => '49',
      'parentid' => '0',
      'categoryname' => '���̶���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    50 => 
    array (
      'id' => '50',
      'parentid' => '0',
      'categoryname' => '�ɷ�����ҵ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    51 => 
    array (
      'id' => '51',
      'parentid' => '0',
      'categoryname' => '���й�˾',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    52 => 
    array (
      'id' => '52',
      'parentid' => '0',
      'categoryname' => '���һ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    53 => 
    array (
      'id' => '53',
      'parentid' => '0',
      'categoryname' => '��ҵ��λ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    54 => 
    array (
      'id' => '54',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_wage' => 
  array (
    55 => 
    array (
      'id' => '55',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    56 => 
    array (
      'id' => '56',
      'parentid' => '0',
      'categoryname' => '1000~1500Ԫ/��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    57 => 
    array (
      'id' => '57',
      'parentid' => '0',
      'categoryname' => '1500~2000Ԫ/��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    58 => 
    array (
      'id' => '58',
      'parentid' => '0',
      'categoryname' => '2000~3000Ԫ/��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    59 => 
    array (
      'id' => '59',
      'parentid' => '0',
      'categoryname' => '3000~5000Ԫ/��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    60 => 
    array (
      'id' => '60',
      'parentid' => '0',
      'categoryname' => '5000~10000Ԫ/��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    61 => 
    array (
      'id' => '61',
      'parentid' => '0',
      'categoryname' => '1������/��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_jobs_nature' => 
  array (
    62 => 
    array (
      'id' => '62',
      'parentid' => '0',
      'categoryname' => 'ȫְ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    63 => 
    array (
      'id' => '63',
      'parentid' => '0',
      'categoryname' => '��ְ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    64 => 
    array (
      'id' => '64',
      'parentid' => '0',
      'categoryname' => 'ʵϰ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_education' => 
  array (
    65 => 
    array (
      'id' => '65',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    66 => 
    array (
      'id' => '66',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    67 => 
    array (
      'id' => '67',
      'parentid' => '0',
      'categoryname' => '�м�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    68 => 
    array (
      'id' => '68',
      'parentid' => '0',
      'categoryname' => '��ר',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    69 => 
    array (
      'id' => '69',
      'parentid' => '0',
      'categoryname' => '��ר',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    70 => 
    array (
      'id' => '70',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    71 => 
    array (
      'id' => '71',
      'parentid' => '0',
      'categoryname' => '˶ʿ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    72 => 
    array (
      'id' => '72',
      'parentid' => '0',
      'categoryname' => '��ʿ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    73 => 
    array (
      'id' => '73',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_experience' => 
  array (
    74 => 
    array (
      'id' => '74',
      'parentid' => '0',
      'categoryname' => '�޾���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    75 => 
    array (
      'id' => '75',
      'parentid' => '0',
      'categoryname' => '1������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    76 => 
    array (
      'id' => '76',
      'parentid' => '0',
      'categoryname' => '1-3��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    77 => 
    array (
      'id' => '77',
      'parentid' => '0',
      'categoryname' => '3-5��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    78 => 
    array (
      'id' => '78',
      'parentid' => '0',
      'categoryname' => '5-10��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    79 => 
    array (
      'id' => '79',
      'parentid' => '0',
      'categoryname' => '10������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_scale' => 
  array (
    80 => 
    array (
      'id' => '80',
      'parentid' => '0',
      'categoryname' => '20������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    81 => 
    array (
      'id' => '81',
      'parentid' => '0',
      'categoryname' => '20-99��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    82 => 
    array (
      'id' => '82',
      'parentid' => '0',
      'categoryname' => '100-499��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    83 => 
    array (
      'id' => '83',
      'parentid' => '0',
      'categoryname' => '500-999��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    84 => 
    array (
      'id' => '84',
      'parentid' => '0',
      'categoryname' => '1000-9999��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    85 => 
    array (
      'id' => '85',
      'parentid' => '0',
      'categoryname' => '10000������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_officebuilding' => 
  array (
    86 => 
    array (
      'id' => '86',
      'parentid' => '0',
      'categoryname' => '����ӯ�Ŵ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    87 => 
    array (
      'id' => '87',
      'parentid' => '0',
      'categoryname' => '�Ƹ�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    88 => 
    array (
      'id' => '88',
      'parentid' => '0',
      'categoryname' => '���ӹ�������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    89 => 
    array (
      'id' => '89',
      'parentid' => '0',
      'categoryname' => '�̵�SOHOͬ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    90 => 
    array (
      'id' => '90',
      'parentid' => '0',
      'categoryname' => '��Ҷ�ִ�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    91 => 
    array (
      'id' => '91',
      'parentid' => '0',
      'categoryname' => '�������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    92 => 
    array (
      'id' => '92',
      'parentid' => '0',
      'categoryname' => 'ε������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    93 => 
    array (
      'id' => '93',
      'parentid' => '0',
      'categoryname' => '��������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    94 => 
    array (
      'id' => '94',
      'parentid' => '0',
      'categoryname' => '��������㳡',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    95 => 
    array (
      'id' => '95',
      'parentid' => '0',
      'categoryname' => '�����������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    96 => 
    array (
      'id' => '96',
      'parentid' => '0',
      'categoryname' => '��������Ԣ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    97 => 
    array (
      'id' => '97',
      'parentid' => '0',
      'categoryname' => '�߿ƹ㳡',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    98 => 
    array (
      'id' => '98',
      'parentid' => '0',
      'categoryname' => 'ҫ�й㳡',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    99 => 
    array (
      'id' => '99',
      'parentid' => '0',
      'categoryname' => '���۹��ʴ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    100 => 
    array (
      'id' => '100',
      'parentid' => '0',
      'categoryname' => '���������������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    101 => 
    array (
      'id' => '101',
      'parentid' => '0',
      'categoryname' => '��������㳡',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    102 => 
    array (
      'id' => '102',
      'parentid' => '0',
      'categoryname' => '�ź��л�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    103 => 
    array (
      'id' => '103',
      'parentid' => '0',
      'categoryname' => '�������ʹ㳡',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    104 => 
    array (
      'id' => '104',
      'parentid' => '0',
      'categoryname' => '�ɳǴ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    105 => 
    array (
      'id' => '105',
      'parentid' => '0',
      'categoryname' => '��ͼʱ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    106 => 
    array (
      'id' => '106',
      'parentid' => '0',
      'categoryname' => '������ʴ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    107 => 
    array (
      'id' => '107',
      'parentid' => '0',
      'categoryname' => '�������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    108 => 
    array (
      'id' => '108',
      'parentid' => '0',
      'categoryname' => '��ó���ʴ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    109 => 
    array (
      'id' => '109',
      'parentid' => '0',
      'categoryname' => '���޹���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    110 => 
    array (
      'id' => '110',
      'parentid' => '0',
      'categoryname' => '��ܲ����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    111 => 
    array (
      'id' => '111',
      'parentid' => '0',
      'categoryname' => '־�ϴ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    112 => 
    array (
      'id' => '112',
      'parentid' => '0',
      'categoryname' => '���޹���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    113 => 
    array (
      'id' => '113',
      'parentid' => '0',
      'categoryname' => '���´���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    114 => 
    array (
      'id' => '114',
      'parentid' => '0',
      'categoryname' => '������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    115 => 
    array (
      'id' => '115',
      'parentid' => '0',
      'categoryname' => '���ɴ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_street' => 
  array (
    116 => 
    array (
      'id' => '116',
      'parentid' => '0',
      'categoryname' => '������·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    117 => 
    array (
      'id' => '117',
      'parentid' => '0',
      'categoryname' => '�����н�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    118 => 
    array (
      'id' => '118',
      'parentid' => '0',
      'categoryname' => '�ӻ����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    119 => 
    array (
      'id' => '119',
      'parentid' => '0',
      'categoryname' => '����·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    120 => 
    array (
      'id' => '120',
      'parentid' => '0',
      'categoryname' => '���·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    121 => 
    array (
      'id' => '121',
      'parentid' => '0',
      'categoryname' => '̫��·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    122 => 
    array (
      'id' => '122',
      'parentid' => '0',
      'categoryname' => '����·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    123 => 
    array (
      'id' => '123',
      'parentid' => '0',
      'categoryname' => '��԰��·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    124 => 
    array (
      'id' => '124',
      'parentid' => '0',
      'categoryname' => '������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    125 => 
    array (
      'id' => '125',
      'parentid' => '0',
      'categoryname' => 'ӭ����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    126 => 
    array (
      'id' => '126',
      'parentid' => '0',
      'categoryname' => 'ˮ���ؽ�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    127 => 
    array (
      'id' => '127',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    128 => 
    array (
      'id' => '128',
      'parentid' => '0',
      'categoryname' => '������·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    129 => 
    array (
      'id' => '129',
      'parentid' => '0',
      'categoryname' => '������Ӫ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    130 => 
    array (
      'id' => '130',
      'parentid' => '0',
      'categoryname' => '�����ؽ�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    131 => 
    array (
      'id' => '131',
      'parentid' => '0',
      'categoryname' => '������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    132 => 
    array (
      'id' => '132',
      'parentid' => '0',
      'categoryname' => '������·',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    133 => 
    array (
      'id' => '133',
      'parentid' => '0',
      'categoryname' => '�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_jobtag' => 
  array (
    134 => 
    array (
      'id' => '134',
      'parentid' => '0',
      'categoryname' => '������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    135 => 
    array (
      'id' => '135',
      'parentid' => '0',
      'categoryname' => '���ս�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    136 => 
    array (
      'id' => '136',
      'parentid' => '0',
      'categoryname' => '˫��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    137 => 
    array (
      'id' => '137',
      'parentid' => '0',
      'categoryname' => '����һ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    138 => 
    array (
      'id' => '138',
      'parentid' => '0',
      'categoryname' => '�Ӱ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    139 => 
    array (
      'id' => '139',
      'parentid' => '0',
      'categoryname' => '��������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    140 => 
    array (
      'id' => '140',
      'parentid' => '0',
      'categoryname' => '��ͨ����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    141 => 
    array (
      'id' => '141',
      'parentid' => '0',
      'categoryname' => '�Ӱಹ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    142 => 
    array (
      'id' => '142',
      'parentid' => '0',
      'categoryname' => '��ʳ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    143 => 
    array (
      'id' => '143',
      'parentid' => '0',
      'categoryname' => '�����淶',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    144 => 
    array (
      'id' => '144',
      'parentid' => '0',
      'categoryname' => '�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    145 => 
    array (
      'id' => '145',
      'parentid' => '0',
      'categoryname' => 'ȫ�ڽ�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    146 => 
    array (
      'id' => '146',
      'parentid' => '0',
      'categoryname' => '�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    147 => 
    array (
      'id' => '147',
      'parentid' => '0',
      'categoryname' => 'ר������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    148 => 
    array (
      'id' => '148',
      'parentid' => '0',
      'categoryname' => '�в���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    149 => 
    array (
      'id' => '149',
      'parentid' => '0',
      'categoryname' => '������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    150 => 
    array (
      'id' => '150',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    151 => 
    array (
      'id' => '151',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    152 => 
    array (
      'id' => '152',
      'parentid' => '0',
      'categoryname' => 'ѹ��С',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    153 => 
    array (
      'id' => '153',
      'parentid' => '0',
      'categoryname' => '������ѵ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    154 => 
    array (
      'id' => '154',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
  'QS_resumetag' => 
  array (
    155 => 
    array (
      'id' => '155',
      'parentid' => '0',
      'categoryname' => '�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    156 => 
    array (
      'id' => '156',
      'parentid' => '0',
      'categoryname' => '���ʼ�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    157 => 
    array (
      'id' => '157',
      'parentid' => '0',
      'categoryname' => '�ܳ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    158 => 
    array (
      'id' => '158',
      'parentid' => '0',
      'categoryname' => '����Ĭ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    159 => 
    array (
      'id' => '159',
      'parentid' => '0',
      'categoryname' => '��������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    160 => 
    array (
      'id' => '160',
      'parentid' => '0',
      'categoryname' => '���׺���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    161 => 
    array (
      'id' => '161',
      'parentid' => '0',
      'categoryname' => '��ѧ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    162 => 
    array (
      'id' => '162',
      'parentid' => '0',
      'categoryname' => '����ḻ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    163 => 
    array (
      'id' => '163',
      'parentid' => '0',
      'categoryname' => '�ܼӰ�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    164 => 
    array (
      'id' => '164',
      'parentid' => '0',
      'categoryname' => '����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    165 => 
    array (
      'id' => '165',
      'parentid' => '0',
      'categoryname' => '�Ὺ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    166 => 
    array (
      'id' => '166',
      'parentid' => '0',
      'categoryname' => '�ڲź�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    167 => 
    array (
      'id' => '167',
      'parentid' => '0',
      'categoryname' => '��������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    168 => 
    array (
      'id' => '168',
      'parentid' => '0',
      'categoryname' => '��Ӧ��',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    169 => 
    array (
      'id' => '169',
      'parentid' => '0',
      'categoryname' => '��ʵ����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    170 => 
    array (
      'id' => '170',
      'parentid' => '0',
      'categoryname' => '�����',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    171 => 
    array (
      'id' => '171',
      'parentid' => '0',
      'categoryname' => '�Ը���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    172 => 
    array (
      'id' => '172',
      'parentid' => '0',
      'categoryname' => '���Ͻ���',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    173 => 
    array (
      'id' => '173',
      'parentid' => '0',
      'categoryname' => '������',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    174 => 
    array (
      'id' => '174',
      'parentid' => '0',
      'categoryname' => '֪ʶ�ḻ',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
    175 => 
    array (
      'id' => '175',
      'parentid' => '0',
      'categoryname' => '���ն�',
      'stat_jobs' => '',
      'stat_resume ' => NULL,
    ),
  ),
);
?>