<?php
$data = array (
  'verify_userreg' => '0',
  'verify_userlogin' => '0',
  'verify_getpwd' => '0',
  'verify_addjob' => '0',
  'verify_resume' => '0',
  'verify_link' => '1',
  'verify_gifts' => '1',
  'verify_simple' => '0',
  'verify_adminlogin' => '0',
  'captcha_width' => '150',
  'captcha_height' => '40',
  'captcha_textcolor' => '',
  'captcha_textfontsize' => '25',
  'captcha_textlength' => '4',
  'captcha_lang' => 'en',
  'captcha_bgcolor' => '',
  'captcha_noisepoint' => '0',
  'captcha_noiseline' => '5',
  'captcha_distortion' => '0',
);
?>