<?php
$dbhost   = "127.0.0.1";

$dbname   = "74cms";

$dbuser   = "root";

$dbpass   = "";

$pre    = "qs_";

$QS_cookiedomain = '';

$QS_cookiepath =  "/";

$QS_pwdhash = "s8g80MzUuwSGNzB?";

define('QISHI_CHARSET','gb2312');

define('QISHI_DBCHARSET','GBK');


define('UC_CONNECT', 'mysql');
define('UC_DBHOST', '127.0.0.1');
define('UC_DBUSER', 'root');
define('UC_DBPW', '');
define('UC_DBNAME', '74cms');
define('UC_DBCHARSET', 'GBK');
define('UC_DBTABLEPRE', 'uc_');
define('UC_DBCONNECT', '0');
define('UC_KEY', '123456');
define('UC_API', 'http://127.0.0.1:8002');
define('UC_CHARSET', 'gb2312');
define('UC_IP', '127.0.0.1');
define('UC_APPID', '1');
define('UC_PPP', '20');
?>