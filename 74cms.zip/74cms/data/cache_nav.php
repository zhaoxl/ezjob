<?php
$data = array (
  'QS_top' => 
  array (
    0 => 
    array (
      'title' => '��  ҳ',
      'url' => '/index.php',
      'target' => '_self',
      'tag' => 'homepage',
    ),
    1 => 
    array (
      'title' => '��Ƹ��Ϣ',
      'url' => '/jobs/',
      'target' => '_blank',
      'tag' => 'jobs',
    ),
    2 => 
    array (
      'title' => '΢��Ƹ',
      'url' => '/simple/simple-list.php',
      'target' => '_self',
      'tag' => 'simple',
    ),
    3 => 
    array (
      'title' => '��ְ��Ϣ',
      'url' => '/resume/',
      'target' => '_blank',
      'tag' => 'resume',
    ),
    4 => 
    array (
      'title' => 'HR������',
      'url' => '/hrtools/hrtools-list.php?id=1',
      'target' => '_self',
      'tag' => 'hrtools',
    ),
    5 => 
    array (
      'title' => '��ҳ',
      'url' => '/company/index.php',
      'target' => '_self',
      'tag' => 'company',
    ),
    6 => 
    array (
      'title' => '������Ѷ',
      'url' => '/news/',
      'target' => '_self',
      'tag' => 'news',
    ),
    7 => 
    array (
      'title' => '��Ա����',
      'url' => '/user/login.php',
      'target' => '_self',
      'tag' => 'user',
    ),
  ),
);
?>