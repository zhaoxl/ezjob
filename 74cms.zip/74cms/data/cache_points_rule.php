<?php
$data = array (
  'jobs_refresh' => 
  array (
    'type' => '2',
    'value' => '0',
  ),
  'jobs_add' => 
  array (
    'type' => '2',
    'value' => '15',
  ),
  'jobs_daily' => 
  array (
    'type' => '2',
    'value' => '1',
  ),
  'resume_download' => 
  array (
    'type' => '2',
    'value' => '1',
  ),
  'resume_download_advanced' => 
  array (
    'type' => '2',
    'value' => '2',
  ),
  'interview_invite' => 
  array (
    'type' => '2',
    'value' => '1',
  ),
  'interview_invite_advanced' => 
  array (
    'type' => '2',
    'value' => '2',
  ),
  'jobs_edit' => 
  array (
    'type' => '2',
    'value' => '3',
  ),
  'company_map' => 
  array (
    'type' => '2',
    'value' => '10',
  ),
  'company_auth' => 
  array (
    'type' => '1',
    'value' => '15',
  ),
  'reg_points' => 
  array (
    'type' => '1',
    'value' => '60',
  ),
  'userlogin' => 
  array (
    'type' => '1',
    'value' => '1',
  ),
  'verifyemail' => 
  array (
    'type' => '1',
    'value' => '3',
  ),
  'verifymobile' => 
  array (
    'type' => '1',
    'value' => '3',
  ),
);
?>