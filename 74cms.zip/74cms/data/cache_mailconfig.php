<?php
$data = array (
  'method' => '1',
  'smtpservers' => '',
  'smtpusername' => '',
  'smtppassword' => '',
  'smtpfrom' => '',
  'smtpport' => '25',
  'set_reg' => '0',
  'set_applyjobs' => '0',
  'set_invite' => '0',
  'set_order' => '0',
  'set_payment' => '0',
  'set_editpwd' => '0',
  'set_jobsallow' => '0',
  'set_jobsnotallow' => '0',
  'set_licenseallow' => '0',
  'set_licensenotallow' => '0',
  'set_addmap' => '0',
  'set_resumeallow' => '0',
  'set_resumenotallow' => '0',
);
?>