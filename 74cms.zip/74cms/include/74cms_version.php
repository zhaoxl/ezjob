<?php
if(!defined('IN_QISHI'))die('Access Denied!');
define('QISHI_VERSION','3.3');
define('QISHI_RELEASE', '20130614');
?>